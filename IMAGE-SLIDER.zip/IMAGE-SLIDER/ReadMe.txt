How to Run the file:-
(note= Download zip file  of iMAGE-SLIDER)
-> Fisrt open the "Image-Slider" folder then you can directly click on "index.html"file.
   the site will open automatically.
-> If the First method Doesn't work then open the "Image-Slider" folder with VS-code app,
   Then click on 'GO-Live' server button present in the bottom-right corner. 
(reminder:- Also include install liver-server extension in VS-code app)